SOCIAL CHANGE & DEVELOPMENT - DIGITAL IEC
Prepared by Cristy B. Barcela

To publish:
1. Open https://app.netlify.com/drop
2. Drag and drop the extracted folder named IEC_Cristy_Barcela_Website.
3. Wait for Netlify to publish the site and provide a public website URL.
4. Open the URL to check the full interactive IEC.
5. Submit that URL in Google Classroom (Add or create > Link).

The main webpage is index.html. Some photographs are loaded from external image hosts, so an internet connection is needed for those images.
